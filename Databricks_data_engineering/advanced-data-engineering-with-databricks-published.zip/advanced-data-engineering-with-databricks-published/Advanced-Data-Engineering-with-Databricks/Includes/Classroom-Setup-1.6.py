# Databricks notebook source
# MAGIC %run ./_databricks-academy-helper $lesson="1.6"

# COMMAND ----------

# MAGIC %run ./_utility-functions

# COMMAND ----------

DA.cleanup()
DA.init()
DA.conclude_setup()

