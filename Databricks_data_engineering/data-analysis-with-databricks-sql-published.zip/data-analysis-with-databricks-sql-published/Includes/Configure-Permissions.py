# Databricks notebook source
# MAGIC %run ./Classroom-Setup-01

# COMMAND ----------

DA.do_for_all_users(DA.update_user_grants)

