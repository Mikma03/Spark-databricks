# Databricks notebook source
spark.sql("GRANT CREATE ON CATALOG TO users")

