# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC 
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md # Project Information
# MAGIC 
# MAGIC * Name: **Just Enough Python for Spark**
# MAGIC * Version:  **2.0.5**
# MAGIC * Built On: **Apr 4, 2021 at 00:32:50 UTC**
# MAGIC * Language: **Python**
