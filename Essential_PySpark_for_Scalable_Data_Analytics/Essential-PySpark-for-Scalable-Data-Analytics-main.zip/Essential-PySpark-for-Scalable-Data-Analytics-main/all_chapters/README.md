## Instructions for Databricks users

If you're using a Databricks environment, you can use the files in the all_chapters folder to recreate all the notebooks. The ```ess_pyspark.dbc``` and ```ess_pyspark.zip``` files are archives of code files for all the chapters. You can import any of these files into your Databricks instance and it will recreate code for all chapters in notebooks along with the folder structure.
